# BioNote
This is my first web development project:
I used node.js, html, css and mongodb to build my project.
It's mainly used to help people build their daily studying notes.

1. landing page:
Dynamic page: pictures can switch every several seconds
You can search the notes you've created like this.

2. user route:
To use it, you first need to register an account and login. You can build your profile, follow other users so that you will be notified when they create new notes.

If you forget your password, you can click the forgot link. In this way, you'll receive a password resetting link in your mail box linked to this account. 

3.todo list route
A data-persistent todo list app in the web

4.Other routes
You can create, re-edit, and delete your notes and related questions. You can also leave a review to any existing notes. The page will automatically calculate the average rating. 
